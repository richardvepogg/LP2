package br.edu.usj.ads.lpii;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.console;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Somar", urlPatterns = {"/Somar"})
public class Somar extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        
      
        String op = request.getParameter("op");
        int a = Integer.parseInt(request.getParameter("a"));
        int b = Integer.parseInt(request.getParameter("b"));
        int res = 0;
       

        if (op.equals("+")) {
            res = a + b;
        }

        if (op.equals("-")) {
            res = a - b;
        }

        if (op.equals("*")) {
            res = a * b;
        }

        if (op.equals("/")) {
            res = a / b;
        }
        
        

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Somar</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>O resultado da soma é " + res + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
