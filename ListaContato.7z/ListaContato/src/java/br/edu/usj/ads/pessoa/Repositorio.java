package br.edu.usj.ads.pessoa;

import java.util.ArrayList;

public class Repositorio {
    
    public ArrayList<Contato> getContatos(){
        Contato contato1 = new Contato();
        Contato contato2 = new Contato();
        Contato contato3 = new Contato();
        
        ArrayList<Contato> contatos = new ArrayList();
        
        contato1.setNome("Pedro");
        contato1.setTelefone("3232-4433");
        
        contato2.setNome("Charles");
        contato2.setTelefone("7565-4323");
        
        contato3.setNome("Bruno");
        contato3.setTelefone("3221-3322");
        
        
        contatos.add(contato1);
        contatos.add(contato2);
        contatos.add(contato3);
        
       return contatos;
  }

}
