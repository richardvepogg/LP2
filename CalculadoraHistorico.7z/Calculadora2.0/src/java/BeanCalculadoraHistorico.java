
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PedroDuca
 */
@ManagedBean
@RequestScoped
//@ApplicationScoped
//@SessionScoped

public class BeanCalculadoraHistorico {
    
    private List<String> historico = new ArrayList<>();
    private int a;
    private int b;
    private int c;

    public List<String> getHistorico() {
        return historico;
    }


    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getC() {
        return c;
    }

    public void setC(int c) {
        this.c = c;
    }
       
    public void somar(){
        int resultado = a + b;
        historico.add(a + " + " + b + " = " + resultado);
    }
    
     public void subtrair(){
        int resultado = a - b;
        historico.add(a + " - " + b + " = " + resultado);
    }
    
    public void limpar(){
        historico.clear();
    }
    
    public void LimparIndice(){
        c = c-1;
        historico.remove(c);
    }
    
    
}
